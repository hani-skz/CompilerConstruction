mc is our file extension abbreviation od "My Compiler". The compiler that we are going to make.
I have a general understanding of the assignment. Yes. Im too tired to write sry ;-;